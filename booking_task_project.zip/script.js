const API = "http://localhost:3000";
let authMode = "login";
let currentUser = null;
let allProducts = [];

const $ = (id) => document.getElementById(id);
const escapeHTML = (value = "") => String(value).replace(/[&<>"']/g, ch => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[ch]));

function setMessage(id, message, isError = false) {
  const node = $(id);
  node.textContent = message;
  node.classList.toggle("error", isError);
}
function validGmail(email) {
  return /^[a-zA-Z0-9._%+-]+@gmail\.com$/i.test(email);
}
async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  if (!response.ok) throw new Error(`API request failed (${response.status})`);
  if (response.status === 204) return null;
  return response.json();
}
function setAuthMode(mode) {
  authMode = mode;
  $("name").hidden = mode !== "signup";
  $("name").required = mode === "signup";
  $("password").autocomplete = mode === "signup" ? "new-password" : "current-password";
  $("login-tab").classList.toggle("active", mode === "login");
  $("signup-tab").classList.toggle("active", mode === "signup");
  $("auth-submit").textContent = mode === "login" ? "Login" : "Create account";
  setMessage("auth-message", "");
}
$("login-tab").addEventListener("click", () => setAuthMode("login"));
$("signup-tab").addEventListener("click", () => setAuthMode("signup"));

$("auth-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const email = $("email").value.trim().toLowerCase();
  const password = $("password").value;
  const name = $("name").value.trim();

  if (!validGmail(email)) {
    setMessage("auth-message", "Please enter a valid @gmail.com address.", true);
    return;
  }
  if (password.length < 8) {
    setMessage("auth-message", "Password must be at least 8 characters.", true);
    return;
  }
  if (authMode === "signup" && !name) {
    setMessage("auth-message", "Please enter your name.", true);
    return;
  }

  try {
    setMessage("auth-message", "Please wait...");
    const users = await api("/users");
    if (authMode === "signup") {
      if (users.some(user => user.email.toLowerCase() === email)) {
        setMessage("auth-message", "This Gmail is already registered. Please login.", true);
        return;
      }
      // DEMO ONLY: json-server cannot securely hash passwords or authenticate sessions.
      // Never use real/reused passwords or deploy this prototype publicly.
      const user = await api("/users", {
        method: "POST",
        body: JSON.stringify({ name, email, password, role: "user" })
      });
      currentUser = user;
    } else {
      const user = users.find(item => item.email.toLowerCase() === email && item.password === password);
      if (!user) {
        setMessage("auth-message", "Gmail or password is incorrect.", true);
        return;
      }
      currentUser = user;
    }
    sessionStorage.setItem("bookingDemoUser", JSON.stringify({
      id: currentUser.id, name: currentUser.name, email: currentUser.email, role: currentUser.role
    }));
    showApp();
  } catch (error) {
    setMessage("auth-message", "Could not connect to API. Start it with npm start.", true);
  }
});

function showApp() {
  $("auth-section").hidden = true;
  $("app-section").hidden = false;
  $("profile-name").textContent = currentUser.name || "User";
  $("profile-email").textContent = currentUser.email;
  $("profile-avatar").textContent = (currentUser.name || "U").charAt(0).toUpperCase();
  $("admin-link").hidden = currentUser.role !== "admin";
  loadProducts();
  loadBookings();
}
$("logout-btn").addEventListener("click", () => {
  sessionStorage.removeItem("bookingDemoUser");
  currentUser = null;
  $("app-section").hidden = true;
  $("auth-section").hidden = false;
  $("password").value = "";
  setAuthMode("login");
});

async function loadProducts() {
  try {
    allProducts = await api("/products");
    $("hero-product-count").textContent = allProducts.length;
    renderProducts(allProducts);
  } catch {
    $("product-list").innerHTML = '<p class="muted">Cannot load products. Make sure the API is running.</p>';
  }
}
function renderProducts(products) {
  if (!products.length) {
    $("product-list").innerHTML = '<p class="muted">No products found. Add the first one below.</p>';
    return;
  }
  $("product-list").innerHTML = products.map(product => `
    <article class="product-card">
      <img class="product-image" src="${escapeHTML(product.image || "https://placehold.co/600x400?text=Product")}" alt="${escapeHTML(product.name)}" onerror="this.src='https://placehold.co/600x400?text=Product'">
      <div class="product-info">
        <span class="category">${escapeHTML(product.category)}</span>
        <h3>${escapeHTML(product.name)}</h3>
        <p>${escapeHTML(product.description)}</p>
        <div class="product-bottom">
          <span class="price">₹${Number(product.price).toLocaleString("en-IN")}</span>
          <button class="book-btn" data-book="${escapeHTML(product.id)}">Book now</button>
        </div>
      </div>
    </article>`).join("");
}
$("product-search").addEventListener("input", () => {
  const term = $("product-search").value.trim().toLowerCase();
  renderProducts(allProducts.filter(p =>
    `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(term)
  ));
});
$("product-list").addEventListener("click", async event => {
  const button = event.target.closest("[data-book]");
  if (!button || !currentUser) return;
  button.disabled = true;
  try {
    const product = allProducts.find(p => String(p.id) === button.dataset.book);
    if (!product) throw new Error("Product not found");
    await api("/bookings", {
      method: "POST",
      body: JSON.stringify({
        userId: currentUser.id,
        userName: currentUser.name,
        userEmail: currentUser.email,
        productId: product.id,
        productName: product.name,
        price: Number(product.price),
        status: "Confirmed",
        createdAt: new Date().toISOString()
      })
    });
    alert("Booking created successfully!");
    await loadBookings();
  } catch {
    alert("Booking failed. Check that the API is running.");
  } finally {
    button.disabled = false;
  }
});

$("product-form").addEventListener("submit", async event => {
  event.preventDefault();
  const name = $("product-name").value.trim();
  const price = Number($("product-price").value);
  const category = $("product-category").value.trim();
  const image = $("product-image").value.trim();
  const description = $("product-description").value.trim();
  if (!name || !category || !description || !Number.isFinite(price) || price <= 0) {
    setMessage("product-message", "Enter valid product details.", true);
    return;
  }
  try {
    await api("/products", {
      method: "POST",
      body: JSON.stringify({
        name, price, category, description,
        image: image || "https://placehold.co/600x400?text=Product",
        createdBy: currentUser.id
      })
    });
    $("product-form").reset();
    setMessage("product-message", "Product added successfully!");
    await loadProducts();
  } catch {
    setMessage("product-message", "Could not add product. Check the API.", true);
  }
});

async function loadBookings() {
  try {
    const bookings = await api("/bookings");
    const mine = bookings.filter(b => String(b.userId) === String(currentUser.id));
    $("hero-booking-count").textContent = mine.length;
    if (!mine.length) {
      $("booking-list").innerHTML = '<p class="muted">You have no bookings yet. Explore products above to get started.</p>';
      return;
    }
    $("booking-list").innerHTML = mine.slice().reverse().map(b => `
      <article class="booking-row">
        <div><h3>${escapeHTML(b.productName)}</h3>
          <p>Booking #${escapeHTML(b.id)} · ${new Date(b.createdAt).toLocaleString()}</p>
          <p>Amount: ₹${Number(b.price).toLocaleString("en-IN")}</p></div>
        <span class="booking-status">${escapeHTML(b.status || "Confirmed")}</span>
      </article>`).join("");
  } catch {
    $("booking-list").innerHTML = '<p class="muted">Could not load bookings. Check the API.</p>';
  }
}

// Demo admin bootstrap: creates a sample admin account if absent.
// This is NOT secure authentication. Do not publish this demo as-is.
async function ensureDemoAdmin() {
  try {
    const users = await api("/users");
    if (!users.some(u => u.email === "admin@gmail.com")) {
      await api("/users", {
        method: "POST",
        body: JSON.stringify({
          name: "Admin", email: "admin@gmail.com",
          password: "AdminDemo123!", role: "admin"
        })
      });
    }
  } catch {}
}
(async function init() {
  await ensureDemoAdmin();
  const saved = sessionStorage.getItem("bookingDemoUser");
  if (saved) {
    try {
      const session = JSON.parse(saved);
      const users = await api("/users");
      const user = users.find(u => String(u.id) === String(session.id));
      if (user) {
        currentUser = { id: user.id, name: user.name, email: user.email, role: user.role };
        showApp();
        return;
      }
    } catch {}
    sessionStorage.removeItem("bookingDemoUser");
  }
  setAuthMode("login");
})();
