const API = "http://localhost:3000";
const $ = id => document.getElementById(id);
const esc = (value = "") => String(value).replace(/[&<>"']/g, c => ({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
}[c]));
async function getData(path) {
  const response = await fetch(`${API}${path}`);
  if (!response.ok) throw new Error("API request failed");
  return response.json();
}
function fillTable(id, rows, columns) {
  const body = $(id);
  if (!rows.length) {
    body.innerHTML = `<tr><td class="empty" colspan="${columns}">No records yet.</td></tr>`;
    return;
  }
  body.innerHTML = rows.map(row => `<tr>${row.map(value => `<td>${esc(value ?? "—")}</td>`).join("")}</tr>`).join("");
}
async function loadDashboard() {
  $("admin-message").textContent = "Loading dashboard...";
  $("admin-message").classList.remove("error");
  try {
    const [users, products, bookings] = await Promise.all([
      getData("/users"), getData("/products"), getData("/bookings")
    ]);
    $("total-users").textContent = users.length;
    $("total-products").textContent = products.length;
    $("total-bookings").textContent = bookings.length;
    $("total-value").textContent = "₹" + bookings.reduce((sum, b) => sum + Number(b.price || 0), 0).toLocaleString("en-IN");
    fillTable("users-table", users.map(u => [u.id, u.name, u.email, u.role || "user"]), 4);
    fillTable("products-table", products.map(p => [p.id, p.name, p.category, "₹" + Number(p.price || 0).toLocaleString("en-IN"), p.createdBy || "Seed product"]), 5);
    fillTable("bookings-table", bookings.slice().reverse().map(b => [
      b.id, b.userName, b.userEmail, b.productName, "₹" + Number(b.price || 0).toLocaleString("en-IN"),
      b.status || "Confirmed", b.createdAt ? new Date(b.createdAt).toLocaleString() : "—"
    ]), 7);
    $("admin-message").textContent = "Dashboard updated.";
  } catch {
    $("admin-message").textContent = "Could not connect to API. Open a terminal in the project folder and run npm start.";
    $("admin-message").classList.add("error");
  }
}
$("refresh-btn").addEventListener("click", loadDashboard);
loadDashboard();
